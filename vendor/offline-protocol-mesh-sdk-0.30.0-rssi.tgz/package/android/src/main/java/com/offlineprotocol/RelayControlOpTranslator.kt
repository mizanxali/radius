package com.offlineprotocol

import org.json.JSONArray
import org.json.JSONObject

/**
 * Translates the SDK's server-plane control frames (tagged by the core via
 * `InternetMessage.control_op`) into the relay's native JSON protocol.
 *
 * The relay does not intercept content prefixes — a self-addressed
 * `__GRP_RELAY_REG__`/`__GRP_RELAY_BCAST__` frame sent as an opaque
 * `SendMessage` is just echoed back — so this translator is the "relay
 * adapter" the core's relay-optimized group path was designed against.
 *
 * Semantics per op:
 * - `group_relay_register` — [Translation.Replace] with `CreateGroup` (the
 *   relay treats a member's re-sync as idempotent and answers `GroupCreated`,
 *   which is the core's sync acknowledgment) plus `AddGroupMember`/
 *   `RemoveGroupMember` deltas against the last *committed* membership.
 *   Member deltas are admin-gated server-side ("Only admins can add
 *   members"): when the payload carries the core's `is_admin=false` hint the
 *   deltas are skipped up front (the admin's own device is the authoritative
 *   registrar), and without the hint a group's first admin-denied GroupError
 *   — recognized only while that group has member deltas awaiting an answer
 *   (see [onGroupError]) — stops further deltas for it this connection;
 *   otherwise every reconnect would re-send N denied deltas whose
 *   group-scoped errors revoke the core's relay sync and surface as
 *   app-visible group_error events.
 * - `group_relay_broadcast` — [Translation.Replace] with `SendGroupMessage`
 *   carrying the MLS ciphertext; the relay fans out `GroupMessageReceived`
 *   per member (bridged back as `__GROUP_MSG__`, MLS-decrypted in core).
 * - `group_mls_leave` — [Translation.Tap]: the per-member leave notification
 *   must still be delivered verbatim, plus one relay-native `LeaveGroup`
 *   (deduped per group) so the relay registry doesn't go stale. The relay
 *   permits self-removal.
 *
 * State commits are deferred: a translation's [Translation.Replace.commit] /
 * [Translation.Tap.commit] must be invoked by the caller ONLY after every
 * frame was written to the socket. A dropped best-effort delta with an
 * optimistically committed snapshot would silently leave that member out of
 * relay fan-out for the rest of the connection; deferring the commit makes
 * the next register/leave re-send the missing frames instead. Commits are
 * additionally generation-guarded: a commit whose translation predates a
 * [reset] is a no-op, so a chain that settles after a disconnect (or
 * RateLimited) cannot write a phantom snapshot into the next connection's
 * diff base.
 *
 * SELF-IDENTITY SPANS TWO NAMESPACES — that is why [isSelf] matches a pair
 * rather than one string. The frames this translator reads come from two
 * different sides, and they name this device differently:
 *
 * - core-fed control payloads (`members`, `leaving_member`) carry the MLS
 *   roster, which since the self-certifying addressing change is `off1…`
 *   ADDRESS space;
 * - relay-fed answers (`GroupRoleChanged`) name members by the relay's
 *   account key, which is USERNAME space (the relay stays username-keyed on
 *   the group path by design).
 *
 * [selfId] is the app-chosen profile, conventionally the relay username;
 * [selfAddress] resolves the derived address lazily, because MLS identity is
 * not necessarily initialized when this translator is constructed and the
 * address can change across an identity rebuild. A comparison against only
 * one of the two silently never matches on the other side's frames, which is
 * what made all three self-checks dead: the SDK named its own address in
 * `AddGroupMember`, never sent a relay-native `LeaveGroup`, and ignored its
 * own admin promotion.
 *
 * Known v1 limitation: a group rename re-registers, but the relay's
 * idempotent sync never updates the stored name (`ON CONFLICT DO NOTHING`).
 *
 * State is per-connection: call [reset] on disconnect.
 * Thread-safe: relay answers (`onGroupError`) arrive on OkHttp's reader
 * thread while `translate` runs on the main handler's poll loop, so all
 * state is guarded by an internal lock. [selfAddress] is always invoked
 * OUTSIDE that lock: it reaches into the protocol's own mutex, and the core
 * never calls back into the translator, so keeping the ordering
 * one-directional is what makes that safe.
 */
class RelayControlOpTranslator(
    private val selfId: String,
    private val selfAddress: () -> String?
) {

    companion object {
        /**
         * Cross-layer contract: substring of the relay server's admin-denial
         * GroupError reasons ("Only admins can add members" / "Only admins
         * can remove members"). The marker alone is NOT enough to suppress
         * deltas — it only counts when the GroupError correlates to member
         * deltas this translator actually has outstanding (see
         * [onGroupError]), so an admin-denial answering some other actor's
         * operation can never permanently silence membership sync. If the
         * relay rewords these, non-admin devices without the core's
         * `is_admin` hint fall back to re-learning the denial each
         * connection — noisy but safe. These strings are an external wire
         * contract — keep them in sync with the denial reasons received over
         * the internet transport.
         */
        internal const val ADMIN_DENIED_REASON_MARKER = "Only admins"

        /**
         * SDK content prefixes only the relay server (bridged by this
         * layer's `injectGroupInternalMessage`) may originate — never a
         * peer. The relay forwards peer message content verbatim, so
         * without this firewall any peer could deliver a crafted
         * `__GROUP_CREATED__` over the authenticated internet path and (in
         * concert with a spoofed registration window) mark a group
         * relay-synced against a relay that never registered it —
         * black-holing broadcasts on a store-less relay. `__GROUP_MSG__` is
         * deliberately absent: it is legitimate peer/relay group traffic.
         */
        private val SERVER_PLANE_ANSWER_PREFIXES = arrayOf(
            "__GROUP_CREATED__",
            "__GROUP_MEMBER_ADDED__",
            "__GROUP_MEMBER_REMOVED__",
            "__GROUP_INFO__",
            "__USER_GROUPS__",
            "__GROUP_ERROR__"
        )

        /**
         * True when peer-delivered message content must be dropped because
         * it impersonates a relay server answer. Called by the
         * `MessageReceived` ingest path with the inner SDK content.
         */
        fun isForgedServerPlaneAnswer(content: String): Boolean =
            SERVER_PLANE_ANSWER_PREFIXES.any { content.startsWith(it) }
    }

    sealed class Translation {
        /**
         * Send these relay-native frames instead of the original message.
         * Invoke [commit] only after ALL frames were written to the socket.
         */
        data class Replace(
            val frames: List<JSONObject>,
            val commit: (() -> Unit)? = null
        ) : Translation()

        /**
         * Send the original message verbatim, then these frames best-effort.
         * Invoke [commit] only after ALL extra frames were written.
         */
        data class Tap(
            val frames: List<JSONObject>,
            val commit: (() -> Unit)? = null
        ) : Translation()

        /** No translation — send the original message verbatim. */
        object PassThrough : Translation()
    }

    private val lock = Any()

    /**
     * Bumped by [reset]. Commit closures capture the generation of their
     * translation and no-op if it moved: state written after a reset would
     * describe frames sent on a connection (or inside a rate budget) the
     * relay already discarded.
     */
    private var generation = 0L

    /** Last membership committed as registered with the relay, per group. */
    private val registeredMembers = HashMap<String, Set<String>>()

    /** Groups whose member deltas the relay denied (we are not the admin). */
    private val memberDeltasDenied = HashSet<String>()

    /**
     * Groups with member deltas outstanding: the window between a
     * translation that produced AddGroupMember/RemoveGroupMember frames and
     * the next group-scoped answer. Only a GroupError landing inside this
     * window may be read as OUR admin denial — the translator never tags
     * request_id, so a group-scoped error with no outstanding deltas belongs
     * to some other actor (an app raw-channel op, another admin's edit).
     * Mirrors ios/RelayControlOpTranslator.swift — keep the two in sync.
     */
    private val outstandingMemberDeltas = HashSet<String>()

    /** Groups for which a relay-native LeaveGroup was already committed. */
    private val leaveSent = HashSet<String>()

    /**
     * True when [id] names this device in either namespace.
     * [resolvedAddress] is the value of [selfAddress] sampled once by the
     * caller before it took the lock — a null (or empty) address degrades to
     * profile-only matching, which is exactly the behavior that predates
     * addressing.
     */
    private fun isSelf(id: String, resolvedAddress: String?): Boolean =
        id == selfId || (!resolvedAddress.isNullOrEmpty() && id == resolvedAddress)

    fun translate(
        controlOp: String,
        controlPayload: String,
        recipientId: String
    ): Translation {
        // Sampled before the lock: resolving the address takes the protocol's
        // mutex, and this translator must never hold its own lock across that.
        val resolvedAddress = selfAddress()
        return translateLocked(controlOp, controlPayload, resolvedAddress)
    }

    private fun translateLocked(
        controlOp: String,
        controlPayload: String,
        resolvedAddress: String?
    ): Translation = synchronized(lock) {
        try {
            when (controlOp) {
                "group_relay_register" -> translateRegister(controlPayload, resolvedAddress)

                "group_relay_broadcast" -> {
                    val payload = JSONObject(controlPayload)
                    val groupId = payload.optString("group_id")
                    if (groupId.isEmpty()) return Translation.PassThrough
                    Translation.Replace(listOf(JSONObject().apply {
                        put("type", "SendGroupMessage")
                        put("group_id", groupId)
                        put("content", payload.optString("ciphertext"))
                        // The core's logical message id for this group
                        // message, stable across broadcast re-sends. A v2
                        // relay echoes it to every member (receiver dedup),
                        // keys its push dedup by it, and names it in the
                        // settled GroupMessageSent delivery report the core
                        // correlates on. Mirrors the DM translator's
                        // message_id stamp; old relays ignore the unknown
                        // field.
                        payload.optString("message_id").takeIf { it.isNotEmpty() }
                            ?.let { put("message_id", it) }
                        payload.optString("reply_to").takeIf { it.isNotEmpty() }
                            ?.let { put("reply_to_msg", it) }
                        // Forward attribution rides the frame so relay-path
                        // receivers can render "forwarded from X" like
                        // mesh-path receivers already do. Dropping it here is
                        // why unsealed forward_info survived over mesh but
                        // vanished over relay. Sealed rich payloads carry
                        // their own copy inside the MLS body and are
                        // unaffected either way. Old relays ignore the
                        // unknown field.
                        //
                        // `epoch` is deliberately NOT forwarded: OpenMLS reads
                        // the epoch from the ciphertext header, so the payload
                        // copy is informational and never consulted on receive.
                        payload.optJSONObject("forward_info")
                            ?.takeIf { it.length() > 0 }
                            ?.let { put("forward_info", it) }
                    }))
                }

                "group_mls_leave" -> {
                    val payload = JSONObject(controlPayload)
                    val groupId = payload.optString("group_id")
                    // `leaving_member` is the core's `local_id` — address
                    // space. A profile-only comparison here never fires,
                    // which left the relay holding us in the group registry
                    // after we left.
                    val leavingMember = payload.optString("leaving_member")
                    if (groupId.isEmpty() ||
                        !isSelf(leavingMember, resolvedAddress) ||
                        leaveSent.contains(groupId)
                    ) {
                        Translation.Tap(emptyList())
                    } else {
                        val gen = generation
                        Translation.Tap(
                            listOf(JSONObject().apply {
                                put("type", "LeaveGroup")
                                put("group_id", groupId)
                            }),
                            commit = { commitLeave(gen, groupId) }
                        )
                    }
                }

                else -> Translation.PassThrough
            }
        } catch (e: Exception) {
            // Malformed control payload: fall back to the verbatim send, the
            // relay-agnostic behavior that existed before translation.
            Translation.PassThrough
        }
    }

    private fun translateRegister(
        controlPayload: String,
        resolvedAddress: String?
    ): Translation {
        val payload = JSONObject(controlPayload)
        val groupId = payload.optString("group_id")
        if (groupId.isEmpty()) return Translation.PassThrough
        val name = payload.optString("group_name").ifEmpty { groupId }
        val members = payload.optJSONArray("members")?.let { array ->
            (0 until array.length()).mapNotNull { array.optString(it).takeIf { m -> m.isNotEmpty() } }
        } ?: emptyList()

        // A register proves membership again: a rejoin after a committed
        // leave must be allowed to send LeaveGroup again later.
        leaveSent.remove(groupId)

        // The core's admin hint: explicitly-not-admin devices never send
        // member deltas (the relay would deny each with a group-scoped
        // GroupError). Absent hint = unknown, fall back to send-and-learn.
        // serde emits a real boolean, but numeric 0/1 encodings are honored
        // too, and anything else (strings included) is treated as absent —
        // exactly NSNumber.boolValue semantics, so both bridges parse the
        // frame identically. Keep in sync with the Swift translator.
        val notAdmin = when (val isAdmin = payload.opt("is_admin")) {
            is Boolean -> !isAdmin
            is Number -> isAdmin.toDouble() == 0.0
            else -> false
        }

        val frames = ArrayList<JSONObject>()
        frames.add(JSONObject().apply {
            put("type", "CreateGroup")
            put("group_id", groupId)
            put("name", name)
        })

        // Member deltas: the relay adds the creator itself, and self-adds are
        // redundant, so the self id never appears in a delta. Sorted for a
        // deterministic wire order across platforms.
        //
        // `members` is the MLS roster — address space. Filtering it against
        // the profile alone strips nothing, which is how the SDK ended up
        // sending an AddGroupMember naming its own address.
        var commit: (() -> Unit)? = null
        if (!notAdmin && !memberDeltasDenied.contains(groupId)) {
            val desired = members.filter { !isSelf(it, resolvedAddress) }.toSet()
            val known = registeredMembers[groupId] ?: emptySet()
            for (added in (desired - known).sorted()) {
                frames.add(JSONObject().apply {
                    put("type", "AddGroupMember")
                    put("group_id", groupId)
                    put("username", added)
                })
            }
            for (removed in (known - desired).sorted()) {
                frames.add(JSONObject().apply {
                    put("type", "RemoveGroupMember")
                    put("group_id", groupId)
                    put("username", removed)
                })
            }
            // Deltas produced: open the group's outstanding-delta window so
            // the next group-scoped GroupError may be read as our denial.
            if (frames.size > 1) {
                outstandingMemberDeltas.add(groupId)
            }
            val gen = generation
            commit = { commitRegisteredMembers(gen, groupId, desired) }
        }
        return Translation.Replace(frames, commit)
    }

    private fun commitRegisteredMembers(generationAtTranslate: Long, groupId: String, members: Set<String>) {
        synchronized(lock) {
            if (generationAtTranslate != generation) return
            // A GroupError may have marked the group admin-denied while the
            // frames were in flight; the denial wins.
            if (!memberDeltasDenied.contains(groupId)) {
                registeredMembers[groupId] = members
            }
        }
    }

    private fun commitLeave(generationAtTranslate: Long, groupId: String) {
        synchronized(lock) {
            if (generationAtTranslate != generation) return
            leaveSent.add(groupId)
            registeredMembers.remove(groupId)
            memberDeltasDenied.remove(groupId)
            // A left group's answers are no longer ours to correlate; a
            // stale window must not let a post-leave GroupError mark a
            // future rejoin as admin-denied.
            outstandingMemberDeltas.remove(groupId)
        }
    }

    /**
     * Feed relay GroupError answers so admin-denied groups stop producing
     * member deltas. The denial is honored ONLY when it correlates to
     * member deltas this translator has outstanding: a `request_id`-carrying
     * error answers an app raw-channel frame (this translator never tags
     * request_id, so it cannot be ours), and without an open per-group
     * delta window the error belongs to some other actor's operation —
     * treating it as ours would permanently suppress membership sync for
     * the group (e.g. an unrelated error quoting a user-authored group
     * name that contains the phrase).
     */
    fun onGroupError(groupId: String, reason: String, requestId: String? = null) {
        if (groupId.isEmpty()) return
        if (!requestId.isNullOrEmpty()) return
        synchronized(lock) {
            if (!outstandingMemberDeltas.contains(groupId)) return
            // The next group-scoped answer closes the window, denial or not.
            outstandingMemberDeltas.remove(groupId)
            if (reason.contains(ADMIN_DENIED_REASON_MARKER, ignoreCase = true)) {
                memberDeltasDenied.add(groupId)
                // The membership snapshot was not applied server-side.
                registeredMembers.remove(groupId)
            }
        }
    }

    /**
     * Feed relay *success* answers on the group channel (GroupCreated,
     * GroupMemberAdded, GroupMemberRemoved): any group-scoped answer closes
     * the admin-denial correlation window, success included — [onGroupError]
     * already closes it for errors. Without this, a successful
     * register-with-deltas leaves the window open for the whole connection,
     * and a later request_id-less GroupError merely *quoting* the denial
     * phrase (e.g. a user-authored group name) would be honored as OUR
     * denial and suppress membership sync until reconnect.
     */
    fun onGroupAnswered(groupId: String) {
        if (groupId.isEmpty()) return
        synchronized(lock) {
            outstandingMemberDeltas.remove(groupId)
        }
    }

    /**
     * Feed relay `GroupRoleChanged` frames: a promotion of this device to
     * admin re-enables member deltas an earlier denial suppressed —
     * otherwise a mid-connection promotion keeps membership edits away from
     * the relay until the next reconnect. (The denial already dropped the
     * group's committed snapshot, so the next register recomputes the full
     * delta set.)
     *
     * [member] is the relay's own naming of the promoted account — username
     * space today (the relay's group path stays username-keyed), which is
     * why [selfId] is the load-bearing half of the match here. The address
     * half costs nothing and keeps this correct if the relay's group naming
     * later moves to address space.
     *
     * Residual, accepted: an app whose relay username differs from its
     * `profile` still fails this match and falls back to re-learning the
     * denial each connection — noisy but safe, the same degradation a
     * reworded denial marker produces.
     */
    fun onRoleChanged(groupId: String, member: String, newRole: String) {
        if (groupId.isEmpty()) return
        if (!newRole.equals("admin", ignoreCase = true)) return
        if (!isSelf(member, selfAddress())) return
        synchronized(lock) {
            memberDeltasDenied.remove(groupId)
        }
    }

    /** Per-connection state: call on disconnect. */
    fun reset() {
        synchronized(lock) {
            generation++
            registeredMembers.clear()
            memberDeltasDenied.clear()
            leaveSent.clear()
            outstandingMemberDeltas.clear()
        }
    }
}
