#!/usr/bin/env bash

# Build UniFFI Android libraries and generate Kotlin bindings
# This script builds the Rust UniFFI library for Android and generates Kotlin bindings
# Compatible with bash 3.2+ (macOS default)
#
# NOTE: CI release workflow (.github/workflows/release.yml) uses inline build
# logic with a matrix strategy instead of this script. If you change build
# targets, linker settings, or output paths here, update release.yml too.

set -e

echo "Building UniFFI Android libraries and generating Kotlin bindings..."

# Navigate to the Rust project root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
OUTPUT_DIR="$SCRIPT_DIR/../android/src/main/jniLibs"

cd "$PROJECT_ROOT"

# Android ABIs and their Rust targets (bash 3.2 compatible)
ABIS=("arm64-v8a" "armeabi-v7a" "x86_64" "x86")
TARGETS=("aarch64-linux-android" "armv7-linux-androideabi" "x86_64-linux-android" "i686-linux-android")

# Check if NDK is available
if [ -z "$ANDROID_NDK_HOME" ] && [ -z "$NDK_HOME" ]; then
  echo "Warning: ANDROID_NDK_HOME or NDK_HOME not set."
  echo "Please set one of these environment variables to your Android NDK path."
  echo "Example: export ANDROID_NDK_HOME=/Users/\$USER/Library/Android/sdk/ndk/25.1.8937393"
  echo ""
  echo "Attempting to find NDK in common locations..."
  
  # Try to find NDK in common locations
  POSSIBLE_NDKS=(
    "$HOME/Library/Android/sdk/ndk"
    "$HOME/Android/Sdk/ndk"
    "/opt/android-ndk"
  )
  
  for ndk_path in "${POSSIBLE_NDKS[@]}"; do
    if [ -d "$ndk_path" ]; then
      # Use the first (usually latest) version found
      NDK_VERSION=$(ls -1 "$ndk_path" | sort -V | tail -1)
      if [ -n "$NDK_VERSION" ]; then
        export ANDROID_NDK_HOME="$ndk_path/$NDK_VERSION"
        echo "Found NDK at: $ANDROID_NDK_HOME"
        break
      fi
    fi
  done
  
  if [ -z "$ANDROID_NDK_HOME" ]; then
    echo "Error: Could not find Android NDK. Please install it or set ANDROID_NDK_HOME."
    exit 1
  fi
fi

# Resolve NDK LLVM toolchain bin directory (supports modern NDK layouts).
LLVM_PREBUILT_ROOT="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt"
if [ ! -d "$LLVM_PREBUILT_ROOT" ]; then
  echo "Error: LLVM prebuilt toolchain root not found: $LLVM_PREBUILT_ROOT"
  exit 1
fi

OS_NAME="$(uname -s)"
ARCH_NAME="$(uname -m)"
TOOLCHAIN_CANDIDATES=()
if [ "$OS_NAME" = "Darwin" ]; then
  if [ "$ARCH_NAME" = "arm64" ]; then
    TOOLCHAIN_CANDIDATES=(
      "$LLVM_PREBUILT_ROOT/darwin-arm64/bin"
      "$LLVM_PREBUILT_ROOT/darwin-aarch64/bin"
      "$LLVM_PREBUILT_ROOT/darwin-x86_64/bin"
    )
  else
    TOOLCHAIN_CANDIDATES=(
      "$LLVM_PREBUILT_ROOT/darwin-x86_64/bin"
      "$LLVM_PREBUILT_ROOT/darwin-arm64/bin"
      "$LLVM_PREBUILT_ROOT/darwin-aarch64/bin"
    )
  fi
elif [ "$OS_NAME" = "Linux" ]; then
  TOOLCHAIN_CANDIDATES=(
    "$LLVM_PREBUILT_ROOT/linux-x86_64/bin"
    "$LLVM_PREBUILT_ROOT/linux-aarch64/bin"
  )
else
  echo "Error: Unsupported OS for Android NDK toolchain resolution: $OS_NAME"
  exit 1
fi

NDK_TOOLCHAIN=""
for candidate in "${TOOLCHAIN_CANDIDATES[@]}"; do
  if [ -d "$candidate" ]; then
    NDK_TOOLCHAIN="$candidate"
    break
  fi
done

if [ -z "$NDK_TOOLCHAIN" ]; then
  echo "Error: Could not find NDK toolchain bin directory under $LLVM_PREBUILT_ROOT"
  echo "Checked:"
  for candidate in "${TOOLCHAIN_CANDIDATES[@]}"; do
    echo "  - $candidate"
  done
  exit 1
fi

export PATH="$NDK_TOOLCHAIN:$PATH"
echo "Using NDK toolchain: $NDK_TOOLCHAIN"

# Configure Rust/Cargo Android linkers explicitly to avoid missing-linker errors.
export CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER="$NDK_TOOLCHAIN/aarch64-linux-android21-clang"
export CARGO_TARGET_ARMV7_LINUX_ANDROIDEABI_LINKER="$NDK_TOOLCHAIN/armv7a-linux-androideabi21-clang"
export CARGO_TARGET_X86_64_LINUX_ANDROID_LINKER="$NDK_TOOLCHAIN/x86_64-linux-android21-clang"
export CARGO_TARGET_I686_LINUX_ANDROID_LINKER="$NDK_TOOLCHAIN/i686-linux-android21-clang"
export AR="$NDK_TOOLCHAIN/llvm-ar"

# The linker settings above are cargo's; cc-rs, which `ring` (the telemetry
# uploader's TLS, via rustls) uses for its C and assembly, never reads them
# and resolves a compiler on its own. It probes PATH for `<triple>-clang`,
# a name no NDK ships, then a fixed list of versioned names, two of which
# (armv7a-linux-androideabi16-clang and i686-linux-android16-clang) are API
# levels that NDK r24 and later no longer carry. So with the toolchain on
# PATH the 64-bit ABIs happen to build and the 32-bit ones fail in ring's
# build script. Name each compiler outright, the same clang the linker uses.
export CC_aarch64_linux_android="$CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER"
export CXX_aarch64_linux_android="${CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER}++"
export CC_armv7_linux_androideabi="$CARGO_TARGET_ARMV7_LINUX_ANDROIDEABI_LINKER"
export CXX_armv7_linux_androideabi="${CARGO_TARGET_ARMV7_LINUX_ANDROIDEABI_LINKER}++"
export CC_x86_64_linux_android="$CARGO_TARGET_X86_64_LINUX_ANDROID_LINKER"
export CXX_x86_64_linux_android="${CARGO_TARGET_X86_64_LINUX_ANDROID_LINKER}++"
export CC_i686_linux_android="$CARGO_TARGET_I686_LINUX_ANDROID_LINKER"
export CXX_i686_linux_android="${CARGO_TARGET_I686_LINUX_ANDROID_LINKER}++"

for linker in \
  "$CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER" \
  "$CARGO_TARGET_ARMV7_LINUX_ANDROIDEABI_LINKER" \
  "$CARGO_TARGET_X86_64_LINUX_ANDROID_LINKER" \
  "$CARGO_TARGET_I686_LINUX_ANDROID_LINKER"; do
  if [ ! -x "$linker" ]; then
    echo "Error: required Android linker not found or not executable: $linker"
    exit 1
  fi
done

# Ensure targets are installed
echo "Installing Android targets..."
for target in "${TARGETS[@]}"; do
  rustup target add "$target"
done

# Build for each ABI
echo "Building UniFFI library for Android ABIs..."
for i in "${!ABIS[@]}"; do
  abi="${ABIS[$i]}"
  target="${TARGETS[$i]}"
  echo "Building for $abi ($target)..."
  
  # Without the C binding: a cdylib exports every C symbol, so the dispatcher
  # behind them could not be stripped (the `capi` feature in the crate).
  cargo build --profile mobile --target "$target" --package offline-protocol-uniffi \
    --no-default-features
  
  # Create output directory for this ABI
  mkdir -p "$OUTPUT_DIR/$abi"
  
  # Cargo may put the cdylib in mobile/ or mobile/deps/
  so_root="$PROJECT_ROOT/target/$target/mobile"
  if [ -f "$so_root/liboffline_protocol_uniffi.so" ]; then
    so_path="$so_root/liboffline_protocol_uniffi.so"
  else
    so_path="$so_root/deps/liboffline_protocol_uniffi.so"
  fi
  
  # Copy library to jniLibs
  # UniFFI generates code that looks for "uniffi_offline_protocol" which JNA converts to "libuniffi_offline_protocol.so"
  cp "$so_path" "$OUTPUT_DIR/$abi/libuniffi_offline_protocol.so"

  # Google Play requires 16 KB page-size alignment (flags live in
  # .cargo/config.toml); fail here rather than package a 4 KB-aligned lib.
  python3 "$SCRIPT_DIR/check-elf-alignment.py" "$OUTPUT_DIR/$abi/libuniffi_offline_protocol.so"

  echo "✅ Built and copied library for $abi"
done

echo ""
echo "Android libraries built and copied to $OUTPUT_DIR"

# Print library info
echo ""
echo "Library sizes:"
for abi in "${ABIS[@]}"; do
  lib_path="$OUTPUT_DIR/$abi/libuniffi_offline_protocol.so"
  if [ -f "$lib_path" ]; then
    size=$(du -h "$lib_path" | cut -f1)
    echo "  $abi: $size"
  fi
done

# Generate bindings — all languages, not just Kotlin: they are one artifact set
# off one UDL (see scripts/generate-bindings.sh).
#
# This used to warn and exit 0 when uniffi-bindgen was missing, on the grounds
# that the native libraries above are the point of the script. That is the one
# tolerance this script cannot afford: freshly built .so files beside the
# previously committed Kotlin *are* the ABI mismatch the whole single-entry-
# point rule exists to prevent, and it fails at the app's first FFI call rather
# than here. Shipping that silently is worse than not building. The generator's
# own error message names the install command, so let it fail.
echo ""
echo "Generating bindings..."

bash "$PROJECT_ROOT/scripts/generate-bindings.sh"

echo ""
echo "✅ Android UniFFI build complete!"

