export declare const LINKING_ERROR: string;
export declare const PROTOCOL_START_DELAY_MS = 100;
export declare const MAX_EVENT_HISTORY = 200;
export declare const ONE_SHOT_EVENT_TYPES: readonly ["internet_session_superseded", "mesh_stopped_by_user"];
export declare const BUFFERED_INBOUND_EVENT_TYPES: readonly ["message_received", "file_received", "message_decryption_failed", "message_delivered", "message_failed"];
export declare const MAX_PENDING_INBOUND_EVENTS = 256;
export declare const NATIVE_EVENT_REPLAY_CAPACITY = 256;
export declare const NATIVE_EVENT_REPLAY_TIMEOUT_MS = 2000;
export declare const MAX_DEFERRED_NATIVE_EVENTS = 1024;
export declare const MESH_WAKE_TASK_KEY = "OfflineProtocolMeshWake";
//# sourceMappingURL=constants.d.ts.map