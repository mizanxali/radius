export declare enum MessagePriority {
    Low = 0,
    Medium = 1,
    High = 2,
    Critical = 3
}
export declare enum ProtocolState {
    Stopped = "Stopped",
    Running = "Running",
    Paused = "Paused"
}
export interface AckConfig {
    defaultTimeoutMs?: number;
    maxPendingAcks?: number;
}
export interface RetryConfig {
    maxRetries?: number;
    initialDelayMs?: number;
    maxDelayMs?: number;
    backoffMultiplier?: number;
    outboxMaxLifetimeMs?: number;
    pendingMessageMaxLifetimeMs?: number;
    edgeDrivenUnreachableDm?: boolean;
}
export interface DedupConfig {
    maxTrackedMessages?: number;
    retentionTimeSecs?: number;
}
export interface MeshRelayConfig {
    maxTtl?: number;
    denseMaxTtl?: number;
    denseDegree?: number;
    fanout?: number;
    jitterMinMs?: number;
    jitterMaxMs?: number;
    ratePerSec?: number;
    burst?: number;
    peerRatePerSec?: number;
    peerBurst?: number;
    queueCapacity?: number;
    biasMinScale?: number;
    biasMaxHandicapMs?: number;
    activityWindowMs?: number;
    activityMinForwards?: number;
    activityIdleWindows?: number;
}
export interface MeshRelayTunables {
    maxTtl: number;
    denseMaxTtl: number;
    denseDegree: number;
    fanout: number;
    jitterMinMs: number;
    jitterMaxMs: number;
    ratePerSec: number;
    burst: number;
    peerRatePerSec: number;
    peerBurst: number;
    queueCapacity: number;
    biasMinScale: number;
    biasMaxHandicapMs: number;
    activityWindowMs: number;
    activityMinForwards: number;
    activityIdleWindows: number;
}
export interface MeshRelayStats {
    forwarded: number;
    transmissions: number;
    queued: number;
    awaitingTransmission: number;
    duplicatesSuppressed: number;
    coveredByANeighbor: number;
    peerRateLimited: number;
    refusedQueueFull: number;
    rateDeferred: number;
    abandonedOverdue: number;
    hopLimitReached: number;
    reachClamped: number;
    droppedForCapacity: number;
}
export interface CustodyConfig {
    enabled?: boolean;
    holdMs?: number;
    maxEntriesPerDepositor?: number;
    maxBytesPerDepositor?: number;
    maxEntries?: number;
    maxBytes?: number;
    strangerMaxEntries?: number;
    strangerMaxBytes?: number;
    overflowPolicy?: 'drop_oldest' | 'drop_newest';
}
export interface CustodyStats {
    held: number;
    heldBytes: number;
    accepted: number;
    delivered: number;
    reOriginated: number;
    expired: number;
    duplicates: number;
    evicted: number;
    receiptsSent: number;
    receiptsDropped: number;
    receiptsReceived: number;
    receiptsIgnored: number;
    refusedDisabled: number;
    refusedNoRequest: number;
    refusedUnknownClass: number;
    refusedNotSealed: number;
    refusedUnprovenPeer: number;
    refusedNotDepositor: number;
    refusedStranger: number;
    refusedDepositorFull: number;
    refusedStoreFull: number;
    refusedBattery: number;
}
export interface DedupStats {
    totalTracked: number;
    recentTracked: number;
    capacityUsedPercent: number;
    mode: string;
}
export interface ReliabilityConfig {
    ack?: AckConfig;
    retry?: RetryConfig;
    dedup?: DedupConfig;
}
export type RelayPriority = 'never' | 'auto' | 'always';
export interface RelayConfig {
    allowRelay?: boolean;
    minBatteryForRelay?: number;
    relayPriority?: RelayPriority;
}
export interface NetworkConfig {
    initialTtl?: number;
}
export interface BleTransportConfig {
    enabled: boolean;
    advertiseNodeHash?: boolean;
}
export interface InternetTransportConfig {
    enabled: boolean;
    serverAddress?: string;
    autoReconnect?: boolean;
    reconnectDelay?: number;
    authToken?: string;
}
export interface WifiDirectTransportConfig {
    enabled: boolean;
    deviceName?: string;
    autoAccept?: boolean;
    groupOwnerIntent?: number;
}
export interface ReticulumTransportConfig {
    enabled: boolean;
    daemonAddress?: string;
    autoReconnect?: boolean;
    maxReconnectAttempts?: number;
}
export interface NostrTransportConfig {
    enabled: boolean;
    relayUrls?: string[];
    connectionTimeout?: number;
    autoReconnect?: boolean;
    reconnectDelay?: number;
    maxReconnectAttempts?: number;
    sealingEnabled?: boolean;
    coldContactEnabled?: boolean;
    usernameDiscoveryEnabled?: boolean;
}
export declare enum ContentType {
    Text = "text",
    Image = "image",
    Video = "video",
    Audio = "audio",
    VoiceNote = "voice_note",
    VideoNote = "video_note",
    File = "file",
    FileChunk = "file_chunk",
    Poll = "poll"
}
export interface MediaMetadata {
    mimeType: string;
    fileName: string;
    fileSize: number;
    durationMs?: number;
    width?: number;
    height?: number;
    thumbnailBase64?: string;
    mediaId?: string;
    downloadUrl?: string;
    thumbnailUrl?: string;
    encryptionKey?: string;
    iv?: string;
    ciphertextHash?: string;
    stickerProvider?: string;
    stickerRemoteId?: string;
    stickerKind?: string;
}
export interface FileTransferConfig {
    chunkSize?: number;
    maxFileSize?: number;
}
export interface FileProgress {
    file_id: string;
    chunks_sent: number;
    total_chunks: number;
    percentage: number;
}
export interface TransportsConfig {
    ble?: BleTransportConfig;
    internet?: InternetTransportConfig;
    wifiDirect?: WifiDirectTransportConfig;
    reticulum?: ReticulumTransportConfig;
    nostr?: NostrTransportConfig;
}
export interface EncryptionConfig {
    enabled?: boolean;
    autoKeyExchange?: boolean;
    storePending?: boolean;
    requireEncryption?: boolean;
    compactEnvelopeEnabled?: boolean;
    richPayloadEnabled?: boolean;
    cryptoRecoveryEnabled?: boolean;
    encryptServiceMessages?: boolean;
    pendingQueue?: PendingQueueConfig;
}
export type OverflowPolicy = 'drop_oldest' | 'drop_newest';
export interface PendingQueueConfig {
    maxPendingPerPeer?: number;
    maxPendingGlobal?: number;
    pendingTtlMs?: number;
    overflowPolicy?: OverflowPolicy;
}
export interface DataConfig {
    enabled?: boolean;
}
export interface ProtocolConfig {
    appId: string;
    profile: string;
    transports?: TransportsConfig;
    binaryWireEnabled?: boolean;
    fileTransfer?: FileTransferConfig;
    encryption?: EncryptionConfig;
    group?: {
        maxGroupMembers?: number;
        relayEnabled?: boolean;
        relayBroadcastEnabled?: boolean;
        enforceAdminCommits?: boolean;
    };
    dors?: {
        preferOnline?: boolean;
        switchHysteresis?: number;
        switchCooldownSecs?: number;
        bleToWifiRetryThreshold?: number;
        minSuccessRateBeforeEscalation?: number;
        minBleSamplesBeforeSuccessRateEscalation?: number;
        rssiSwitchThreshold?: number;
        congestionQueueThreshold?: number;
        stabilityWindowSecs?: number;
        poorSignalDurationSecs?: number;
        ttlEscalationThreshold?: number;
        congestionDurationSecs?: number;
        ttlEscalationHoldSecs?: number;
        historyWindowSize?: number;
        queueRecoveryRatio?: number;
        lowBatteryThreshold?: number;
        relayMinBatteryLevel?: number;
        relayOptimalConnectionCount?: number;
    };
    meshRelay?: MeshRelayConfig;
    custody?: CustodyConfig;
    relay?: RelayConfig;
    network?: NetworkConfig;
    reliability?: ReliabilityConfig;
    data?: DataConfig;
    security?: SecurityConfig;
    controlFreshnessEnforced?: boolean;
}
export interface SecurityConfig {
    controlFreshnessEnforced?: boolean;
}
export type TransportType = 'ble' | 'internet' | 'wifiDirect' | 'reticulum' | 'nostr';
export interface ForwardInfo {
    original_sender: string;
    original_message_id: string;
    original_timestamp: number;
    forward_count: number;
}
export interface ReplyContext {
    sender: string;
    text: string;
    timestamp?: number;
    reply_media_label?: string;
    reply_content_type?: string;
}
export interface MediaMetadataEvent {
    mime_type?: string;
    file_name?: string;
    file_size?: number;
    duration_ms?: number;
    width?: number;
    height?: number;
    thumbnail_base64?: string;
    media_id?: string;
    download_url?: string;
    thumbnail_url?: string;
    encryption_key?: string;
    iv?: string;
    ciphertext_hash?: string;
    sticker_provider?: string;
    sticker_remote_id?: string;
    sticker_kind?: string;
}
export interface ForwardMessageParams {
    originalMessageJson: string;
    newRecipient: string;
    priority?: MessagePriority;
}
export interface ForwardMessageToGroupParams {
    originalMessageJson: string;
    groupId: string;
    priority?: MessagePriority;
}
export interface SendMessageParams {
    recipient: string;
    content: string;
    priority?: MessagePriority;
    replyToMsg?: string;
    contentType?: ContentType;
    replyContext?: ReplyContext;
    mediaMetadata?: MediaMetadata;
    forwardInfo?: ForwardInfo;
    appId?: string;
}
export interface SendConnectionRequestParams {
    recipient: string;
    senderName: string;
    keyPackage?: number[];
    initialMessage?: string;
}
export interface AcceptConnectionRequestParams {
    recipient: string;
    accepterName: string;
    keyPackage?: number[];
}
export interface RejectConnectionRequestParams {
    recipient: string;
}
export interface CancelConnectionRequestParams {
    recipient: string;
}
export interface SendMediaParams {
    recipient: string;
    fileData: string;
    fileName: string;
    contentType: ContentType;
    mediaMetadata?: MediaMetadata;
    caption?: string;
    replyToMsg?: string;
    replyContext?: ReplyContext;
    forwardInfo?: ForwardInfo;
    fileId?: string;
    appId?: string;
}
export interface SendFileParams {
    recipient: string;
    fileData: string;
    fileName: string;
}
export interface SendFileFromPathParams {
    recipient: string;
    filePath: string;
    fileName: string;
}
interface BaseEvent {
    type: string;
    seenAt?: number;
}
export interface MessageSentEvent extends BaseEvent {
    type: 'message_sent';
    message_id: string;
    sender: string;
    recipient: string;
    content: string;
    priority: 'low' | 'medium' | 'high' | 'critical';
    requires_ack: boolean;
    timestamp: number;
    lamport_clock: number;
    forward_info?: ForwardInfo;
}
export interface MessageReceivedEvent extends BaseEvent {
    type: 'message_received';
    message_id: string;
    sender: string;
    recipient: string;
    content: string;
    hop_count: number;
    transport: string;
    timestamp: number;
    lamport_clock: number;
    encrypted?: boolean;
    reply_to_msg?: string;
    reply_context?: ReplyContext;
    content_type?: string;
    media_metadata?: MediaMetadataEvent;
    forward_info?: ForwardInfo;
    app_id: string;
}
export interface MessageDeliveredEvent extends BaseEvent {
    type: 'message_delivered';
    message_id: string;
    latency_ms: number;
    hop_count: number;
    transport: string;
}
export interface MessageFailedEvent extends BaseEvent {
    type: 'message_failed';
    message_id: string;
    reason: string;
    retry_count: number;
}
export type DecryptionFailureCode = 'INVALID_PAYLOAD' | 'NOT_INITIALIZED' | 'INVALID_CIPHERTEXT' | 'IDENTITY_MISMATCH' | 'CRYPTO_FAILURE' | 'PENDING_QUEUE_DROPPED' | 'UNKNOWN';
export interface MessageDecryptionFailedEvent extends BaseEvent {
    type: 'message_decryption_failed';
    message_id: string;
    sender: string;
    code: DecryptionFailureCode;
    reason: string;
    sealed_at_ms: number | null;
    session_established_at_ms: number | null;
}
export interface TransportSwitchedEvent extends BaseEvent {
    type: 'transport_switched';
    from: string | null;
    to: string;
    reason: string;
}
export interface RelayPromotedEvent extends BaseEvent {
    type: 'relay_promoted';
    connection_count: number;
    battery_level: number | null;
}
export interface RelayDemotedEvent extends BaseEvent {
    type: 'relay_demoted';
    reason: string;
}
export interface RelayDemotedBatteryEvent extends BaseEvent {
    type: 'relay_demoted_battery';
    battery_level: number;
    min_required: number;
}
export interface NeighborDiscoveredEvent extends BaseEvent {
    type: 'neighbor_discovered';
    peer_id: string;
    transport: string;
    rssi?: number;
}
export interface NeighborLostEvent extends BaseEvent {
    type: 'neighbor_lost';
    peer_id: string;
}
export interface PeerRssiEvent extends BaseEvent {
    type: 'peer_rssi';
    peer_id: string;
    transport: string;
    rssi: number;
}
export interface IdentityReadyEvent extends BaseEvent {
    type: 'identity_ready';
    address: string;
}
export interface NetworkMetricsEvent extends BaseEvent {
    type: 'network_metrics';
    neighbor_count: number;
    relay_count: number;
    delivery_ratio: number;
    avg_latency_ms: number;
}
export interface FileProgressEvent extends BaseEvent {
    type: 'file_progress';
    file_id: string;
    chunks_sent: number;
    total_chunks: number;
    percentage: number;
}
export interface FileReceivedEvent extends BaseEvent {
    type: 'file_received';
    file_id: string;
    file_name: string;
    file_size: number;
    sender: string;
    content_type: string;
    media_metadata?: MediaMetadataEvent;
    file_data: string;
    timestamp?: number;
    caption?: string;
    reply_to_msg?: string;
    reply_context?: ReplyContext;
    forward_info?: ForwardInfo;
    app_id?: string;
}
export interface FileReceiveFailedEvent extends BaseEvent {
    type: 'file_receive_failed';
    file_id: string;
    file_name: string;
    sender: string;
    reason: string;
}
export interface MediaSentEvent extends BaseEvent {
    type: 'media_sent';
    file_id: string;
    content_type: string;
    recipient: string;
}
export interface MediaSendFailedEvent extends BaseEvent {
    type: 'media_send_failed';
    file_id: string;
    recipient: string;
    reason: string;
}
export interface AckEvictedEvent extends BaseEvent {
    type: 'ack_evicted';
    message_id: string;
    priority: string;
    reason: string;
}
export interface FragmentAssemblyEvictedEvent extends BaseEvent {
    type: 'fragment_assembly_evicted';
    message_id: string;
    completion_percent: number;
    reason: string;
}
export interface DiagnosticEvent extends BaseEvent {
    type: 'diagnostic';
    level: 'debug' | 'info' | 'warning' | 'error';
    message: string;
    context?: Record<string, unknown>;
}
export interface SecureSessionEstablishedEvent extends BaseEvent {
    type: 'secure_session_established';
    peer_id: string;
    group_id: string;
    is_session: boolean;
    initiated_by_local: boolean;
}
export interface SecureSessionFailedEvent extends BaseEvent {
    type: 'secure_session_failed';
    peer_id: string;
    reason: string;
}
export interface ConvergenceDiagEvent extends BaseEvent {
    type: 'convergence_diag';
    stage: string;
    peer_id: string;
    detail: string;
}
export type WelcomeReasonCode = 'TRANSPORT_UNAVAILABLE' | 'PEER_UNREACHABLE' | 'PEER_DISCONNECTED' | 'TIMEOUT' | 'INTERNAL_ERROR' | 'RETRY_EXHAUSTED';
export interface WelcomeSendAttemptedEvent extends BaseEvent {
    type: 'welcome_send_attempted';
    peer_id: string;
    message_id: string;
    group_id: string;
    attempt: number;
}
export interface WelcomeSendSucceededEvent extends BaseEvent {
    type: 'welcome_send_succeeded';
    peer_id: string;
    message_id: string;
    group_id: string;
    attempt: number;
}
export interface WelcomeSendFailedEvent extends BaseEvent {
    type: 'welcome_send_failed';
    peer_id: string;
    message_id: string;
    group_id: string;
    attempt: number;
    reason_code: WelcomeReasonCode;
    transport_error?: string;
    retryable: boolean;
    next_retry_at?: number;
}
export interface WelcomeSendExpiredEvent extends BaseEvent {
    type: 'welcome_send_expired';
    peer_id: string;
    message_id: string;
    attempt: number;
    reason_code: WelcomeReasonCode;
}
export interface ConnectionRequestReceivedEvent extends BaseEvent {
    type: 'connection_request_received';
    sender: string;
    sender_name: string;
    timestamp: number;
    key_package?: number[];
    initial_message?: string;
}
export interface ConnectionRequestUndeliverableEvent extends BaseEvent {
    type: 'connection_request_undeliverable';
    recipient: string;
    message_id: string;
    reason: string;
}
export interface ConnectionAcceptedEvent extends BaseEvent {
    type: 'connection_accepted';
    accepted_by: string;
    accepted_by_name: string;
    timestamp: number;
    key_package?: number[];
}
export interface ConnectionRejectedEvent extends BaseEvent {
    type: 'connection_rejected';
    rejected_by: string;
}
export interface ConnectionRequestCancelledEvent extends BaseEvent {
    type: 'connection_request_cancelled';
    cancelled_by: string;
}
export interface GroupCreatedEvent extends BaseEvent {
    type: 'group_created';
    group_id: string;
    name: string;
}
export interface GroupMessageReceivedEvent extends BaseEvent {
    type: 'group_message_received';
    group_id: string;
    sender: string;
    content: string;
    timestamp: string;
    message_id: string;
    reply_to_msg?: string;
    forward_info?: ForwardInfo;
    media_metadata?: MediaMetadataEvent;
    content_type?: string;
}
export interface GroupMemberAddedEvent extends BaseEvent {
    type: 'group_member_added';
    group_id: string;
    user_id: string;
    added_by: string;
    group_name?: string;
    authorized?: boolean;
}
export interface GroupMemberRemovedEvent extends BaseEvent {
    type: 'group_member_removed';
    group_id: string;
    user_id: string;
    removed_by: string;
    authorized?: boolean;
}
export interface GroupInfoMemberEvent {
    user_id: string;
    role: string;
    joined_at: string;
}
export interface GroupInfoEvent extends BaseEvent {
    type: 'group_info';
    group_id: string;
    name: string;
    created_by: string;
    created_at: string;
    members: GroupInfoMemberEvent[];
}
export interface UserGroupSummaryEvent {
    group_id: string;
    name: string;
    created_at: string;
}
export interface UserGroupsEvent extends BaseEvent {
    type: 'user_groups';
    groups: UserGroupSummaryEvent[];
}
export interface GroupErrorEvent extends BaseEvent {
    type: 'group_error';
    reason: 'not_found' | 'sync_denied' | 'error';
    group_id?: string;
}
export interface GroupRelaySyncChangedEvent extends BaseEvent {
    type: 'group_relay_sync_changed';
    group_id: string;
    synced: boolean;
    reason: string;
}
export interface InviteInfo {
    address: string;
    public_key: number[];
    petname: string | null;
    signed: boolean;
}
export interface UsernameClaim {
    address: string;
    public_key: string;
    issued_at_ms: number;
}
export interface UsernameResolvedEvent extends BaseEvent {
    type: 'username_resolved';
    username: string;
    claims: UsernameClaim[];
    rejected: number;
    truncated: number;
}
export interface GroupMessageSentEvent extends BaseEvent {
    type: 'group_message_sent';
    group_id: string;
    message_ids: string[];
    member_count: number;
}
export interface GroupMessagePartialFailureEvent extends BaseEvent {
    type: 'group_message_partial_failure';
    group_id: string;
    failed_members: string[];
    succeeded_members: string[];
}
export interface GroupMessageDeliveryReportEvent extends BaseEvent {
    type: 'group_message_delivery_report';
    group_id: string;
    message_id: string;
    delivered: string[];
    pushed: string[];
    missed_reissued: string[];
}
export interface GroupRichExtrasDroppedEvent extends BaseEvent {
    type: 'group_rich_extras_dropped';
    group_id: string;
    unknown_members: string[];
}
export interface GroupUnauthorizedMembershipChangeEvent extends BaseEvent {
    type: 'group_unauthorized_membership_change';
    group_id: string;
    committer: string;
    added: string[];
    removed: string[];
    reason: string;
    enforced: boolean;
}
export interface GroupEpochForkDetectedEvent extends BaseEvent {
    type: 'group_epoch_fork_detected';
    group_id: string;
    local_epoch?: number;
}
export interface GroupEpochForkResolvedEvent extends BaseEvent {
    type: 'group_epoch_fork_resolved';
    group_id: string;
    resolved_epoch: number;
    failed_members: string[];
}
export interface GroupRoleChangedEvent extends BaseEvent {
    type: 'group_role_changed';
    group_id: string;
    user_id: string;
    new_role: string;
    changed_by: string;
}
export interface GroupRenamedEvent extends BaseEvent {
    type: 'group_renamed';
    group_id: string;
    new_name: string;
    old_name: string | null;
    renamed_by: string;
}
export interface ServiceDiscoveredEvent extends BaseEvent {
    type: 'service_discovered';
    query_id: string;
    service_id: string;
    version: string;
    provider_peer_id: string;
    capabilities: Record<string, string>;
    hop_count: number;
}
export interface ServiceRequestReceivedEvent extends BaseEvent {
    type: 'service_request_received';
    request_id: string;
    service_id: string;
    method: string;
    body: string;
    sender: string;
    encrypted: boolean;
}
export interface ServiceResponseReceivedEvent extends BaseEvent {
    type: 'service_response_received';
    request_id: string;
    service_id: string;
    status: string;
    body: string;
    provider_peer_id: string;
    encrypted: boolean;
}
export type PresenceStatus = 'online' | 'away' | 'offline';
export type PresenceSource = 'internet' | 'reticulum' | 'peer';
export interface PresenceUpdatedEvent extends BaseEvent {
    type: 'presence_updated';
    peer_id: string;
    status: PresenceStatus;
    timestamp: number;
    last_seen_ms?: number;
    source: PresenceSource;
}
export interface TypingIndicatorReceivedEvent extends BaseEvent {
    type: 'typing_indicator_received';
    sender: string;
    conversation_id: string;
    is_typing: boolean;
    timestamp: number;
}
export interface ReadReceiptReceivedEvent extends BaseEvent {
    type: 'read_receipt_received';
    sender: string;
    message_ids: string[];
    timestamp: number;
}
export interface MessageRelayedEvent extends BaseEvent {
    type: 'message_relayed';
    message_id: string;
    sender: string;
    recipient: string;
    hop_count: number;
    remaining_ttl: number;
}
export interface MessageDeferredEvent extends BaseEvent {
    type: 'message_deferred';
    message_id: string;
    recipient: string;
    reason: string;
    retry_count: number;
    next_retry_at?: number;
}
export interface MessageRetryingEvent extends BaseEvent {
    type: 'message_retrying';
    message_id: string;
    recipient: string;
    retry_count: number;
    next_retry_at: number;
}
export interface MessageUndeliverableEvent extends BaseEvent {
    type: 'message_undeliverable';
    message_id: string;
    recipient: string;
    reason: string;
    file_id?: string;
}
export interface MediaResendRequiredEvent extends BaseEvent {
    type: 'media_resend_required';
    file_id: string;
    recipient: string;
    file_name: string;
    file_size: number;
    app_id?: string;
}
export type DorsReasonCode = 'INITIAL_SELECTION' | 'PRIMARY_SELECTED' | 'PRIMARY_SUCCESS' | 'FALLBACK_SUCCESS' | 'ESCALATION_APPLIED' | 'CURRENT_UNAVAILABLE';
export type DorsEscalationPhase = 'TRIGGERED' | 'APPLIED';
export type DorsEscalationReasonCode = 'FALLBACK_SUCCESS' | 'RETRY_THRESHOLD' | 'POOR_SIGNAL' | 'CONGESTION' | 'LOW_TTL' | 'LOW_SUCCESS_RATE';
export interface DorsScoreUpdatedEvent extends BaseEvent {
    type: 'dors_score_updated';
    scores: Array<[string, number]>;
}
export interface DorsTransportSelectedEvent extends BaseEvent {
    type: 'dors_transport_selected';
    from: string | null;
    transport: string;
    reason_code: DorsReasonCode;
    score?: number;
}
export interface DorsTransportSwitchedEvent extends BaseEvent {
    type: 'dors_transport_switched';
    from: string | null;
    to: string;
    reason_code: DorsReasonCode;
    reason_detail?: string;
}
export interface DorsEscalationTriggeredEvent extends BaseEvent {
    type: 'dors_escalation_triggered';
    phase: DorsEscalationPhase;
    from: string;
    to: string;
    reason_code: DorsEscalationReasonCode;
    reason_detail?: string;
}
export type SecurityWarningCode = 'SENDER_ADDRESS_MISMATCH' | 'TRANSPORT_IDENTITY_MISMATCH' | 'CONTROL_SIGNATURE_INVALID' | 'UNSIGNED_CONTROL_REJECTED' | 'MEDIA_SENDER_GROUP_MISMATCH' | 'PLAINTEXT_SEND' | 'PLAINTEXT_RECEIVE_REJECTED' | 'SESSION_SENDER_GROUP_MISMATCH' | 'SESSION_REKEY_TRIGGERED' | 'NOSTR_KEY_PACKAGE_SLOT_EXHAUSTED' | 'PUSH_KEY_PACKAGE_POOL_EXHAUSTED' | 'RELAY_ADDRESS_BINDING_MISMATCH' | 'RELAY_ADDRESS_DECLARATION_REFUSED' | 'GROUP_LEAF_IDENTITY_UNPROVEN' | 'STALE_CONTROL_FRAME' | 'GATEWAY_ADDRESS_BINDING_MISMATCH' | 'GATEWAY_ADDRESS_DECLARATION_REFUSED' | 'KEY_PACKAGE_OUTSIDE_VALIDITY_WINDOW';
export interface SecurityWarningEvent extends BaseEvent {
    type: 'security_warning';
    peer_id: string;
    reason_code: SecurityWarningCode;
    reason: string;
}
export interface UserBlockedEvent extends BaseEvent {
    type: 'user_blocked';
    user_id: string;
}
export interface UserUnblockedEvent extends BaseEvent {
    type: 'user_unblocked';
    user_id: string;
}
export interface DataChangedEvent extends BaseEvent {
    type: 'data_changed';
    space_id: string;
    doc_id: string;
    delta_bytes: number;
}
export interface DataDocRemovedEvent extends BaseEvent {
    type: 'data_doc_removed';
    space_id: string;
    doc_id: string;
    by: 'local' | 'peer';
}
export interface DataDocSizeWarningEvent extends BaseEvent {
    type: 'data_doc_size_warning';
    space_id: string;
    doc_id: string;
    compacted_bytes: number;
    cap_bytes: number;
}
export interface DataAttachmentRequestedEvent extends BaseEvent {
    type: 'data_attachment_requested';
    space_id: string;
    peer_id: string;
    hash: string;
}
export interface DataAttachmentReceivedEvent extends BaseEvent {
    type: 'data_attachment_received';
    space_id: string;
    peer_id: string;
    hash: string;
    data: string;
}
export interface DataAttachmentUnavailableEvent extends BaseEvent {
    type: 'data_attachment_unavailable';
    space_id: string;
    peer_id: string;
    hash: string;
    reason: string;
}
export interface DataDocUnsyncableEvent extends BaseEvent {
    type: 'data_doc_unsyncable';
    space_id: string;
    doc_id: string;
    bytes: number;
    reason: string;
}
export interface InternetServerMessageEvent extends BaseEvent {
    type: 'internet_server_message';
    json: string;
}
export interface InternetStatusChangedEvent extends BaseEvent {
    type: 'internet_status_changed';
    connected: boolean;
    authenticated: boolean;
}
export interface InternetSessionSupersededEvent extends BaseEvent {
    type: 'internet_session_superseded';
    reason?: string;
}
export interface MeshStoppedByUserEvent extends BaseEvent {
    type: 'mesh_stopped_by_user';
}
export type RelaySyncState = 'synced' | 'pending' | 'unsynced';
export type ProtocolEvent = MessageSentEvent | MessageReceivedEvent | MessageDeliveredEvent | MessageFailedEvent | MessageDecryptionFailedEvent | TransportSwitchedEvent | RelayPromotedEvent | RelayDemotedEvent | RelayDemotedBatteryEvent | NeighborDiscoveredEvent | NeighborLostEvent | PeerRssiEvent | IdentityReadyEvent | NetworkMetricsEvent | FileProgressEvent | FileReceivedEvent | FileReceiveFailedEvent | MediaSentEvent | MediaSendFailedEvent | AckEvictedEvent | FragmentAssemblyEvictedEvent | DiagnosticEvent | SecureSessionEstablishedEvent | SecureSessionFailedEvent | ConvergenceDiagEvent | WelcomeSendAttemptedEvent | WelcomeSendSucceededEvent | WelcomeSendFailedEvent | WelcomeSendExpiredEvent | ConnectionRequestReceivedEvent | ConnectionRequestUndeliverableEvent | ConnectionAcceptedEvent | ConnectionRejectedEvent | ConnectionRequestCancelledEvent | GroupCreatedEvent | GroupMessageReceivedEvent | GroupMemberAddedEvent | GroupMemberRemovedEvent | GroupInfoEvent | UserGroupsEvent | GroupErrorEvent | GroupRelaySyncChangedEvent | UsernameResolvedEvent | GroupMessageSentEvent | GroupMessagePartialFailureEvent | GroupMessageDeliveryReportEvent | GroupRichExtrasDroppedEvent | GroupUnauthorizedMembershipChangeEvent | GroupEpochForkDetectedEvent | GroupEpochForkResolvedEvent | GroupRoleChangedEvent | GroupRenamedEvent | DorsScoreUpdatedEvent | DorsTransportSelectedEvent | DorsTransportSwitchedEvent | DorsEscalationTriggeredEvent | ServiceDiscoveredEvent | ServiceRequestReceivedEvent | ServiceResponseReceivedEvent | PresenceUpdatedEvent | InternetServerMessageEvent | InternetStatusChangedEvent | InternetSessionSupersededEvent | MeshStoppedByUserEvent | TypingIndicatorReceivedEvent | ReadReceiptReceivedEvent | MessageRelayedEvent | MessageDeferredEvent | MessageRetryingEvent | MessageUndeliverableEvent | MediaResendRequiredEvent | SecurityWarningEvent | UserBlockedEvent | UserUnblockedEvent | DataChangedEvent | DataDocRemovedEvent | DataDocSizeWarningEvent | DataAttachmentRequestedEvent | DataAttachmentReceivedEvent | DataAttachmentUnavailableEvent | DataDocUnsyncableEvent;
export type EventListener<T extends ProtocolEvent = ProtocolEvent> = (event: T) => void;
export type EventType = ProtocolEvent['type'];
export declare enum NodeRole {
    Normal = "normal",
    Relay = "relay"
}
export interface NetworkNode {
    user_id: string;
    role: NodeRole;
    connection_count: number;
    battery_level?: number;
    last_seen: number;
    transports: TransportType[];
}
export interface NetworkLink {
    from: string;
    to: string;
    quality: number;
    transport: TransportType;
    rssi?: number;
}
export interface NetworkStats {
    total_nodes: number;
    relay_nodes: number;
    total_connections: number;
    avg_link_quality: number;
    network_diameter?: number;
}
export interface NetworkTopology {
    timestamp: number;
    local_user_id: string;
    nodes: NetworkNode[];
    links: NetworkLink[];
    stats: NetworkStats;
}
export interface MessageDeliveryStats {
    message_id: string;
    sender: string;
    recipient: string;
    sent_at: number;
    delivered_at?: number;
    hop_count: number;
    transport?: TransportType;
    retry_count: number;
    latency_ms?: number;
}
export interface ProcessFileChunkParams {
    fileId: string;
    chunkIndex: number;
    data: number[];
}
export interface WifiDirectMessage {
    recipientId: string;
    data: number[];
}
export interface InternetMessage {
    messageId: string;
    recipientId: string;
    data: number[];
}
export type EstablishmentState = 'NoKeyPackage' | 'HaveKeyPackage' | 'SessionPending' | 'SessionConfirmed';
export interface MlsKeyPackage {
    packageId: string;
    userId: string;
    keyPackageData: number[];
    createdAt: number;
    expiresAt: number;
    isSynced: boolean;
}
export interface MlsEncryptedMessage {
    groupId: string;
    messageType: string;
    epoch: number;
    ciphertext: number[];
    senderId: string;
    timestampMs: number;
}
export interface MlsWelcome {
    groupId: string;
    welcomeData: number[];
    inviterId: string;
    timestampMs: number;
}
export interface MlsSessionInfo {
    otherUserId: string;
    groupId: string;
    epoch: number;
    createdAt: number;
}
export interface MlsGroupInfo {
    groupId: string;
    groupName: string;
    memberIds: string[];
    epoch: number;
    createdAt: number;
}
export interface GroupRichReadiness {
    ready: boolean;
    unknownMembers: string[];
}
export interface MlsCommit {
    groupId: string;
    commitData: number[];
    newEpoch: number;
}
export type MlsVerbosity = 'off' | 'lifecycle' | 'diagnostic';
export interface TelemetryConfig {
    apiKey: string;
    appId: string;
    appVersion?: string;
    debug?: boolean;
    flushIntervalMs?: number;
    maxBatchBytes?: number;
    maxBufferedRecords?: number;
    includeDeviceId?: boolean;
    scrubIds?: boolean;
    mlsVerbosity?: MlsVerbosity;
    metricsCadenceMs?: number;
    routingDiagnostic?: boolean;
    mlsSamplingBypass?: boolean;
}
export interface TelemetryStats {
    buffered: number;
    sentEvents: number;
    acceptedEvents: number;
    dropped: number;
    sessionId: string;
    lastError?: string;
    lastFlushAtMs?: number;
}
export interface BleDiagnostics {
    fragmentFallbacks: number;
    recipientNotAmongPeers: number;
    undersizedMtuReports: number;
}
export interface TransportMetrics {
    packetsSent: number;
    packetsReceived: number;
    bytesSent: number;
    bytesReceived: number;
    errorRate: number;
    avgLatencyMs: number;
    rssi?: number;
    bandwidthBps?: number;
    congestion?: number;
    queueDepth?: number;
    batteryLevel?: number;
    isCharging?: boolean;
    relayConnectionCount?: number;
    isActiveRelay?: boolean;
    deliveryRatio?: number;
    dropRate?: number;
    averageHopCount?: number;
    energyCost?: number;
}
export interface MeshWakeTaskData {
    reason: 'sticky_restart' | (string & {});
}
export {};
//# sourceMappingURL=types.d.ts.map